package com.operit.silentcamera;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class CameraActivity extends Activity {
    private static final String TAG = "SilentCamera";
    
    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private ImageReader imageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    
    private String outputPath;
    private String cameraId;
    private boolean isFrontCamera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Intent intent = getIntent();
        outputPath = intent.getStringExtra("output_path");
        isFrontCamera = intent.getBooleanExtra("front_camera", false);
        
        if (outputPath == null || outputPath.isEmpty()) {
            outputPath = "/sdcard/DCIM/Camera/silent_" + System.currentTimeMillis() + ".jpg";
        }
        
        Log.d(TAG, "Taking photo to: " + outputPath + ", front=" + isFrontCamera);
        
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "No camera permission");
            finishWithError("No camera permission");
            return;
        }
        
        startBackgroundThread();
        openCamera();
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Interrupted while stopping background thread", e);
            }
        }
    }

    private void openCamera() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String[] cameraIdList = cameraManager.getCameraIdList();
            
            for (String id : cameraIdList) {
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                
                if (isFrontCamera && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    cameraId = id;
                    break;
                } else if (!isFrontCamera && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    break;
                }
            }
            
            if (cameraId == null) {
                finishWithError("Camera not found");
                return;
            }
            
            imageReader = ImageReader.newInstance(1920, 1080, ImageFormat.JPEG, 1);
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        if (image != null) {
                            saveImage(image);
                        }
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                    }
                }
            }, backgroundHandler);
            
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                finishWithError("No camera permission");
                return;
            }
            
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    cameraDevice = camera;
                    takePicture();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    cameraDevice = null;
                    finishWithError("Camera disconnected");
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    cameraDevice = null;
                    finishWithError("Camera error: " + error);
                }
            }, backgroundHandler);
            
        } catch (Exception e) {
            Log.e(TAG, "Error opening camera", e);
            finishWithError("Error: " + e.getMessage());
        }
    }

    private void takePicture() {
        try {
            final CaptureRequest.Builder captureBuilder = 
                cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(imageReader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            captureBuilder.set(CaptureRequest.JPEG_QUALITY, (byte) 95);
            
            CaptureRequest captureRequest = captureBuilder.build();
            
            cameraDevice.createCaptureSession(Arrays.asList(imageReader.getSurface()),
                new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigured(CameraCaptureSession session) {
                        try {
                            session.capture(captureRequest, new CameraCaptureSession.CaptureCallback() {
                                @Override
                                public void onCaptureCompleted(CameraCaptureSession session, 
                                                              CaptureRequest request, 
                                                              TotalCaptureResult result) {
                                    Log.d(TAG, "Capture completed");
                                }
                            }, backgroundHandler);
                        } catch (Exception e) {
                            Log.e(TAG, "Capture error", e);
                            finishWithError("Capture error: " + e.getMessage());
                        }
                    }

                    @Override
                    public void onConfigureFailed(CameraCaptureSession session) {
                        finishWithError("Configuration failed");
                    }
                }, backgroundHandler);
                
        } catch (Exception e) {
            Log.e(TAG, "Error taking picture", e);
            finishWithError("Error: " + e.getMessage());
        }
    }

    private void saveImage(Image image) {
        FileOutputStream output = null;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            
            File file = new File(outputPath);
            File parentDir = file.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }
            
            output = new FileOutputStream(file);
            output.write(bytes);
            
            Log.d(TAG, "Image saved to: " + outputPath);
            finishWithSuccess();
            
        } catch (Exception e) {
            Log.e(TAG, "Error saving image", e);
            finishWithError("Save error: " + e.getMessage());
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (Exception e) {
                    Log.e(TAG, "Error closing output", e);
                }
            }
        }
    }

    private void finishWithSuccess() {
        cleanup();
        setResult(RESULT_OK);
        finish();
    }

    private void finishWithError(String error) {
        Log.e(TAG, error);
        cleanup();
        setResult(RESULT_CANCELED);
        finish();
    }

    private void cleanup() {
        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        stopBackgroundThread();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cleanup();
    }
}